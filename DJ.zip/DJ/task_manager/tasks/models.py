from django.db import models
from django.contrib.auth.models import User


"""Модель Task которая добавляется в базу данных"""
class Task(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    project = models.ForeignKey('projects.Project', on_delete=models.CASCADE)
    assignee = models.ForeignKey('users.CustomUser', on_delete=models.SET_NULL, null=True)
    status = models.CharField(max_length=50)
    priority = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    due_date = models.DateTimeField()
    tester = models.ForeignKey('users.CustomUser', on_delete=models.SET_NULL, null=True, related_name='tested_tasks')

"""Модель Comment которая добавляется в базу данных"""
class Comment(models.Model):
    task = models.ForeignKey('Task', on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey('users.CustomUser', on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.author}: {self.text[:20]}"