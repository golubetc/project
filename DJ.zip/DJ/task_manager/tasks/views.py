from rest_framework import viewsets, permissions
from .models import Task, Comment
from .serializers import TaskSerializer, TaskDetailSerializer, CommentSerializer
from rest_framework import filters
from django_filters.rest_framework import DjangoFilterBackend, FilterSet, DateFromToRangeFilter
from rest_framework.response import Response
from rest_framework.decorators import action


class TaskFilter(FilterSet):
    created_at = DateFromToRangeFilter()
    updated_at = DateFromToRangeFilter()
    deadline = DateFromToRangeFilter()

    class Meta:
        model = Task
        fields = ['created_at', 'updated_at', 'deadline']

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['created_at', 'updated_at']

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return TaskDetailSerializer
        return TaskSerializer

class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [permissions.AllowAny]

    def perform_create(self, serializer):
        """
        Установка текущего пользователя как автора комментария при создании.
        """
        serializer.save(author=self.request.user)

    @action(detail=True, methods=['get'], url_path='history')
    def history(self, request, pk=None):
        """
        Возвращает историю комментариев для указанного задания.
        """
        comment = self.get_object()
        history = Comment.objects.filter(task=comment.task).order_by('-created_at')
        serializer = self.get_serializer(history, many=True)
        return Response(serializer.data)