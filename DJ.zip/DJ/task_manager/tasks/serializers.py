from rest_framework import serializers
from .models import Task, Comment
from users.models import CustomUser

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['username']


class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = ['id', 'name', 'description', 'project', 'assignee', 'status', 'priority', 'created_at', 'updated_at', 'due_date', 'tester']
        

class TaskDetailSerializer(serializers.ModelSerializer):
    comments = serializers.SerializerMethodField()

    class Meta:
        model = Task
        fields = ['id', 'name', 'description', 'project', 'assignee', 'status', 'priority', 'created_at', 'updated_at', 'due_date', 'tester', 'comments']

    def get_comments(self, obj):
        comments = Comment.objects.filter(task=obj)
        return CommentSerializer(comments, many=True).data

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ['id', 'task', 'author', 'text', 'created_at', 'updated_at']