from django.contrib import admin
from django.urls import path, include
from users.views import UserViewSet, UserRegistrationViewSet, UserProfileViewSet, CustomTokenObtainPairView, CustomTokenRefreshView, some_protected_view
from projects.views import ProjectViewSet
from tasks.views import TaskViewSet, CommentViewSet
from notifications.views import NotificationView
from rest_framework.routers import DefaultRouter
from django.conf.urls.static import static
from django.conf import settings

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'register', UserRegistrationViewSet, basename='user-registration')
router.register(r'profile', UserProfileViewSet, basename='profile')
router.register(r'projects', ProjectViewSet)
router.register(r'tasks', TaskViewSet)
router.register(r'comments', CommentViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', CustomTokenRefreshView.as_view(), name='token_refresh'),
    path('api/notifications/', NotificationView.as_view(), name='notifications'),
    path('protected-resource', some_protected_view, name='protected_resource'),  
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)