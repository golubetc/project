from rest_framework import views, permissions
from rest_framework.response import Response
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

class NotificationView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request, format=None):
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"user_{request.user.id}",
            {
                "type": "send_notification",
                "message": request.data.get("message", ""),
            },
        )
        return Response({"status": "notification sent"})