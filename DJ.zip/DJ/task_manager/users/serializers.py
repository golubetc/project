from rest_framework import serializers
from .models import CustomUser
from projects.serializers import ProjectSerializer
from rest_framework_simplejwt.tokens import RefreshToken

from django.contrib.auth.hashers import make_password

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    password2 = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password', 'password2', 'first_name', 'last_name', 'avatar', 'role']

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Passwords do not match."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2') 
        validated_data['password'] = make_password(validated_data['password'])
        return CustomUser.objects.create(**validated_data)



"""class для сериализации данных User"""
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'first_name', 'last_name', 'avatar', 'role', 'current_projects']


"""class для сериализации данных Profile"""
class UserProfileSerializer(serializers.ModelSerializer):
    current_projects = ProjectSerializer(many=True, read_only=True)

    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'first_name', 'last_name', 'avatar', 'role', 'current_projects']


from rest_framework_simplejwt.serializers import TokenObtainPairSerializer, TokenRefreshSerializer

"""class для дополнительного дополнения данных пользователя"""
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['username'] = user.username
        token['first_name'] = user.first_name
        token['last_name'] = user.last_name
        token['avatar'] = user.avatar.url if user.avatar else None
        token['role'] = user.role
        return token

"""class для обновления токена без изменений"""
class CustomTokenRefreshSerializer(TokenRefreshSerializer):
    pass