from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from .models import CustomUser
from .serializers import UserSerializer, UserRegistrationSerializer, UserProfileSerializer
from django.shortcuts import render
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from django.contrib.auth.models import User
from urllib.parse import urlencode
from rest_framework.decorators import api_view, permission_classes
from rest_framework.viewsets import GenericViewSet
from rest_framework.permissions import AllowAny

"""класс который возвращает данные User в апи и позволет изменять,удалять,обновлять и удалять модели"""
class UserViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class UserRegistrationViewSet(GenericViewSet):
    permission_classes = [AllowAny]
    serializer_class = UserRegistrationSerializer
    
    def create(self, request, *args, **kwargs):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)  # Генерация токенов для нового пользователя
            return Response({
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                },
                "refresh": str(refresh),
                "access": str(refresh.access_token),
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


"""класс который возвращает данные Profile в апи и позволет изменять,удалять,обновлять и удалять модели"""
class UserProfileViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    """Возвращаем текущего пользователя"""
    def get_object(self):
        return self.request.user
    
@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def some_protected_view(request):
    return Response({"message": "You have accessed a protected resource!"})
    
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .serializers import CustomTokenObtainPairSerializer, CustomTokenRefreshSerializer


"""класс повзоляет настраивать получение токена"""

class CustomTokenObtainPairView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)  # Получение стандартного ответа
        data = response.data  # Данные с токенами (access и refresh)

        # Проверяем, если токен успешно создан
        if "access" in data:
            access_token = data["access"]
            
            # Формируем новый URL с токеном в пути
            new_path = f"/protected-resource?{urlencode({'token': access_token})}"
            
            # Возвращаем новый путь в ответе
            return Response(
                {"detail": "Login successful.", "redirect_to": new_path},
                status=status.HTTP_200_OK
            )

        # Если что-то пошло не так, возвращаем стандартный ответ
        return response
    
    
"""класс который обновляет токен"""
class CustomTokenRefreshView(TokenRefreshView):
    serializer_class = CustomTokenRefreshSerializer